class AppConstants {
  static const String baseUrl = "https://smart-institute-api-production.up.railway.app";
  static const String roleStudent    = "student";
  static const String roleDoctor     = "doctor";
  static const String roleAdmin      = "admin";
  static const String appName        = "Smart Institute App";
  static const int    maxCreditHours = 18;
}
