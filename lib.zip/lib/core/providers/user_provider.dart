import 'package:flutter/foundation.dart';

class UserProvider extends ChangeNotifier {
  String? _name;
  String? _firebaseUid;
  String? _role;
  String? _username;
  String? _studentCode;
  String? _level;
  double? _gpa;
  int?    _creditHours;
  int?    _warnings;

  String? get name        => _name;
  String? get firebaseUid => _firebaseUid;
  String? get role        => _role;
  String? get username    => _username;
  String? get studentCode => _studentCode;
  String? get level       => _level;
  double? get gpa         => _gpa;
  int?    get creditHours => _creditHours;
  int?    get warnings    => _warnings;
  bool    get isLoggedIn  => _firebaseUid != null;

  void setUser({
    required String name,
    required String firebaseUid,
    required String role,
    String? username,
    String? studentCode,
    String? level,
    double? gpa,
    int?    creditHours,
    int?    warnings,
  }) {
    _name        = name;
    _firebaseUid = firebaseUid;
    _role        = role;
    _username    = username;
    _studentCode = studentCode;
    _level       = level;
    _gpa         = gpa;
    _creditHours = creditHours;
    _warnings    = warnings;
    notifyListeners();
  }

  void clearUser() {
    _name = _firebaseUid = _role = _username = _studentCode = _level = null;
    _gpa = null;
    _creditHours = _warnings = null;
    notifyListeners();
  }
}
