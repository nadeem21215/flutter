import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'core/constants/app_theme.dart';
import 'core/providers/user_provider.dart';
import 'views/splash/splash_screen.dart';
import 'views/onboarding/onboarding_screen.dart';
import 'views/auth/login_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(
    MultiProvider(
      providers: [ChangeNotifierProvider(create: (_) => UserProvider())],
      child: const SmartInstituteApp(),
    ),
  );
}

class SmartInstituteApp extends StatelessWidget {
  const SmartInstituteApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title:                    'Smart Institute App',
    debugShowCheckedModeBanner: false,
    theme:                    AppTheme.theme,
    initialRoute:             SplashScreen.routeName,
    routes: {
      SplashScreen.routeName:     (_) => const SplashScreen(),
      OnboardingScreen.routeName: (_) => const OnboardingScreen(),
      LoginScreen.routeName:      (_) => const LoginScreen(),
    },
  );
}
