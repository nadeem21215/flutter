import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../core/constants/app_constants.dart';
import '../../core/network/http_exception.dart';
import '../models/models.dart';

class ApiService {
  static final ApiService _i = ApiService._();
  factory ApiService() => _i;
  ApiService._();
  static const _timeout = Duration(seconds: 15);
  Map<String, String> get _headers => {'Content-Type':'application/json','Accept':'application/json'};

  dynamic _handle(http.Response res) {
    if (res.statusCode >= 200 && res.statusCode < 300) return jsonDecode(utf8.decode(res.bodyBytes));
    switch (res.statusCode) {
      case 401: throw const HttpException(message: 'Incorrect username or password', statusCode: 401);
      case 404: throw const HttpException(message: 'Data not found', statusCode: 404);
      case 409: throw const HttpException(message: 'Already registered', statusCode: 409);
      default:  throw HttpException(message: 'Server error: ${res.statusCode}', statusCode: res.statusCode);
    }
  }

  Future<UserModel> login({required String username, required String password}) async {
    try {
      final loginRes = await http.post(
        Uri.parse('${AppConstants.baseUrl}/login').replace(queryParameters: {'student_code':username,'password':password})
      ).timeout(_timeout);
      final d = _handle(loginRes) as Map<String,dynamic>;
      final uid = d['firebase_uid'] as String;
      final role = d['role'] as String;
      final name = d['name'] as String? ?? '';
      if (role == 'student') {
        final profileRes = await http.get(Uri.parse('${AppConstants.baseUrl}/student/profile/$uid')).timeout(_timeout);
        final p = _handle(profileRes) as Map<String,dynamic>;
        return UserModel(
          name: p['name'] as String? ?? name, firebaseUid: uid, role: role,
          studentCode: username, level: 'Year ${p['current_year']} - Term ${p['current_term']}',
          gpa: (p['gpa'] as num?)?.toDouble(),
          creditHours: (p['total_passed_credit_hours'] as num?)?.toInt() ?? 0,
          warnings: (p['warnings'] as num?)?.toInt() ?? 0,
        );
      }
      return UserModel(name: name, firebaseUid: uid, role: role);
    } on HttpException { rethrow; }
    catch (e) { throw HttpException(message: 'Cannot connect to server.\n$e'); }
  }

  Future<List<ScheduleItem>> getSchedule({required String firebaseUid}) async => [];

  Future<List<CourseModel>> getCourses({required String firebaseUid}) async {
    try {
      final res = await http.get(Uri.parse('${AppConstants.baseUrl}/courses?firebase_uid=$firebaseUid'), headers: _headers).timeout(_timeout);
      return (_handle(res) as List).map((e) => CourseModel.fromJson(e)).toList();
    } on HttpException { rethrow; }
    catch (e) { throw HttpException(message: 'Failed to load courses: $e'); }
  }

  Future<List<CourseModel>> getStudentRegisteredCourses({required String firebaseUid}) async {
    try {
      final res = await http.get(Uri.parse('${AppConstants.baseUrl}/student/courses/$firebaseUid'), headers: _headers).timeout(_timeout);
      final data = _handle(res) as Map<String, dynamic>;
      final list = data['registered_courses'] as List? ?? [];
      return list.map((e) => CourseModel(
        id:          ((e['code'] as String).hashCode & 0x7FFFFFFF),
        name:        e['name']         as String,
        code:        e['code']         as String,
        creditHours: e['credit_hours'] as int,
        isEnrolled:  true,
        isAvailable: true,
      )).toList();
    } on HttpException { rethrow; }
    catch (e) { throw HttpException(message: 'Failed to load courses: $e'); }
  }

  Future<void> enrollCourses({required String firebaseUid, required List<int> courseIds}) async {
    throw const HttpException(message: 'Use enrollCourseByCodes instead');
  }

  Future<void> enrollCourseByCodes({required String firebaseUid, required List<String> courseCodes}) async {
    try {
      final res = await http.post(
        Uri.parse('${AppConstants.baseUrl}/enroll').replace(queryParameters: {'firebase_uid':firebaseUid,'course_ids':courseCodes.join(',')})
      ).timeout(_timeout);
      _handle(res);
    } on HttpException { rethrow; }
    catch (e) { throw HttpException(message: 'Enrollment failed: $e'); }
  }

  Future<List<CourseModel>> getDoctorCourses({required String firebaseUid}) async => [];

  Future<List<StudentModel>> getDoctorStudents({required String firebaseUid}) async {
    try {
      final res = await http.get(Uri.parse('${AppConstants.baseUrl}/students'), headers: _headers).timeout(_timeout);
      return (_handle(res) as List).map((e) => StudentModel.fromJson(e)).toList();
    } on HttpException { rethrow; }
    catch (e) { throw HttpException(message: 'Failed to load students: $e'); }
  }

  Future<AdminStats> getAdminStats() async {
    try {
      final res = await http.get(Uri.parse('${AppConstants.baseUrl}/stats'), headers: _headers).timeout(_timeout);
      return AdminStats.fromJson(_handle(res) as Map<String,dynamic>);
    } on HttpException { rethrow; }
    catch (e) { throw HttpException(message: 'Failed to load stats: $e'); }
  }

  Future<List<StudentModel>> getAllStudents() async {
    try {
      final res = await http.get(Uri.parse('${AppConstants.baseUrl}/students'), headers: _headers).timeout(_timeout);
      return (_handle(res) as List).map((e) => StudentModel.fromJson(e)).toList();
    } on HttpException { rethrow; }
    catch (e) { throw HttpException(message: 'Failed to load students: $e'); }
  }

  Future<StudentModel> getStudentDetail({required int studentId}) async {
    try {
      final res = await http.get(Uri.parse('${AppConstants.baseUrl}/students/$studentId'), headers: _headers).timeout(_timeout);
      return StudentModel.fromJson(_handle(res) as Map<String,dynamic>);
    } on HttpException { rethrow; }
    catch (e) { throw HttpException(message: 'Failed to load student: $e'); }
  }

  Future<List<CourseModel>> getAllCourses() async {
    try {
      final res = await http.get(Uri.parse('${AppConstants.baseUrl}/curriculum'), headers: _headers).timeout(_timeout);
      final data = _handle(res) as Map<String,dynamic>;
      final curriculum = data['curriculum'] as Map<String,dynamic>;
      final list = <CourseModel>[];
      for (final term in curriculum.values) {
        for (final c in term as List) {
          list.add(CourseModel(id:(c['code'] as String).hashCode & 0x7FFFFFFF,
            name:c['name'] as String, code:c['code'] as String, creditHours:c['credit_hours'] as int));
        }
      }
      return list;
    } on HttpException { rethrow; }
    catch (e) { throw HttpException(message: 'Failed to load courses: $e'); }
  }

  Future<void> addCourse({required String name, required String code, required int creditHours}) async {
    throw const HttpException(message: 'Not supported');
  }

  Future<void> removeCourse({required int courseId}) async {
    throw const HttpException(message: 'Not supported');
  }

  Future<void> addCourseToStudent({
    required int    studentId,
    required int    courseId,
    String?         courseCode,
  }) async {
    try {
      final res = await http.post(
        Uri.parse('${AppConstants.baseUrl}/add_course'),
        headers: _headers,
        body: jsonEncode({'student_id': studentId, 'course_code': courseCode ?? ''}),
      ).timeout(_timeout);
      _handle(res);
    } on HttpException { rethrow; }
    catch (e) { throw HttpException(message: 'Failed to add course: $e'); }
  }

  Future<void> removeCourseFromStudent({
    required int    studentId,
    required int    courseId,
    String?         courseCode,
  }) async {
    try {
      final res = await http.post(
        Uri.parse('${AppConstants.baseUrl}/remove_course'),
        headers: _headers,
        body: jsonEncode({'student_id': studentId, 'course_code': courseCode ?? ''}),
      ).timeout(_timeout);
      _handle(res);
    } on HttpException { rethrow; }
    catch (e) { throw HttpException(message: 'Failed to remove course: $e'); }
  }
}
