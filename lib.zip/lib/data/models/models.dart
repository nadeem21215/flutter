// ─── User ─────────────────────────────────────────────────────────────────────
class UserModel {
  final String  name;
  final String  firebaseUid;
  final String  role;
  final String? studentCode;
  final String? level;
  final double? gpa;
  final int?    creditHours;
  final int?    warnings;

  const UserModel({
    required this.name,
    required this.firebaseUid,
    required this.role,
    this.studentCode,
    this.level,
    this.gpa,
    this.creditHours,
    this.warnings,
  });

  factory UserModel.fromJson(Map<String, dynamic> j) => UserModel(
    name:        j['name']         as String,
    firebaseUid: j['firebase_uid'] as String,
    role:        j['role']         as String,
    studentCode: j['student_code'] as String?,
    level:       j['level']        as String?,
    gpa:         (j['gpa'] as num?)?.toDouble(),
    creditHours: j['credit_hours'] as int?,
    warnings:    j['warnings']     as int?,
  );
}

// ─── Course ───────────────────────────────────────────────────────────────────
class CourseModel {
  final int    id;
  final String name;
  final String code;
  final int    creditHours;
  final bool   isEnrolled;
  final bool   isAvailable;   // false = greyed out (credit limit reached)

  const CourseModel({
    required this.id,
    required this.name,
    required this.code,
    required this.creditHours,
    this.isEnrolled   = false,
    this.isAvailable  = true,
  });

  factory CourseModel.fromJson(Map<String, dynamic> j) => CourseModel(
    id:          j['id']           as int,
    name:        j['name']         as String,
    code:        j['code']         as String,
    creditHours: (j['credit_hours'] as int?) ?? 3,
    isEnrolled:  (j['is_enrolled']  as bool?) ?? false,
    isAvailable: (j['is_available'] as bool?) ?? true,
  );

  CourseModel copyWith({bool? isEnrolled, bool? isAvailable}) => CourseModel(
    id:          id,
    name:        name,
    code:        code,
    creditHours: creditHours,
    isEnrolled:  isEnrolled  ?? this.isEnrolled,
    isAvailable: isAvailable ?? this.isAvailable,
  );
}

// ─── Schedule Item ────────────────────────────────────────────────────────────
class ScheduleItem {
  final String courseName;
  final String days;
  final String timeFrom;
  final String timeTo;

  const ScheduleItem({
    required this.courseName,
    required this.days,
    required this.timeFrom,
    required this.timeTo,
  });

  factory ScheduleItem.fromJson(Map<String, dynamic> j) => ScheduleItem(
    courseName: j['course_name'] as String,
    days:       j['days']        as String,
    timeFrom:   j['time_from']   as String,
    timeTo:     j['time_to']     as String,
  );

  String get timeRange => '$timeFrom – $timeTo';
}

// ─── Student ──────────────────────────────────────────────────────────────────
class StudentModel {
  final int     id;
  final String  name;
  final String  studentCode;
  final String? level;
  final double? gpa;
  final int?    creditHours;
  final int?    warnings;
  final List<CourseModel> courses;

  const StudentModel({
    required this.id,
    required this.name,
    required this.studentCode,
    this.level,
    this.gpa,
    this.creditHours,
    this.warnings,
    this.courses = const [],
  });

  factory StudentModel.fromJson(Map<String, dynamic> j) => StudentModel(
    id:          j['id']           as int,
    name:        j['name']         as String,
    studentCode: j['student_code'] as String,
    level:       j['level']        as String?,
    gpa:         (j['gpa'] as num?)?.toDouble(),
    creditHours: j['credit_hours'] as int?,
    warnings:    j['warnings']     as int?,
    courses: (j['courses'] as List<dynamic>?)
        ?.map((e) => CourseModel.fromJson(e as Map<String, dynamic>))
        .toList() ?? [],
  );
}

// ─── Admin Stats ──────────────────────────────────────────────────────────────
class AdminStats {
  final int    studentCount;
  final int    courseCount;
  final String academicYear;

  const AdminStats({
    required this.studentCount,
    required this.courseCount,
    required this.academicYear,
  });

  factory AdminStats.fromJson(Map<String, dynamic> j) => AdminStats(
    studentCount: j['student_count'] as int,
    courseCount:  j['course_count']  as int,
    academicYear: j['academic_year'] as String,
  );
}
