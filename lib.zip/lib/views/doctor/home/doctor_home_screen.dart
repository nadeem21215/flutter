import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/user_images.dart';
import '../../../core/providers/user_provider.dart';
import '../../../data/models/models.dart';
import '../../../data/services/api_service.dart';
import '../../widgets/shared_widgets.dart';

class DoctorHomeScreen extends StatefulWidget {
  const DoctorHomeScreen({super.key});
  @override
  State<DoctorHomeScreen> createState() => _DoctorHomeScreenState();
}

class _DoctorHomeScreenState extends State<DoctorHomeScreen> {
  final _api = ApiService();
  late Future<List<CourseModel>>  _coursesFuture;
  late Future<List<ScheduleItem>> _scheduleFuture;

  @override
  void initState() { super.initState(); _load(); }

  void _load() {
    final uid = context.read<UserProvider>().firebaseUid ?? '';
    _coursesFuture  = _api.getDoctorCourses(firebaseUid: uid);
    _scheduleFuture = _api.getSchedule(firebaseUid: uid);
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<UserProvider>();
    final imageBytes = UserImages.getImageBytes(user.firebaseUid);
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () async => setState(_load),
          color: AppColors.primary,
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                CircleAvatar(
                  radius: 26,
                  backgroundColor: AppColors.cardGray,
                  backgroundImage: imageBytes != null ? MemoryImage(imageBytes) : null,
                  child: imageBytes == null ? const Icon(Icons.person_rounded, color: AppColors.textGray, size: 28) : null,
                ),
                const SizedBox(width: 12),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Text('Hi ${user.name ?? 'Doctor'}!', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.textDark, fontFamily: 'Poppins')),
                    const SizedBox(width: 6),
                    const Text('👋', style: TextStyle(fontSize: 18)),
                  ]),
                  const Text('Doctor', style: TextStyle(color: AppColors.textGray, fontSize: 13, fontFamily: 'Poppins')),
                ]),
              ]),
              const SizedBox(height: 28),
              const Text('My Courses', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textDark, fontFamily: 'Poppins')),
              const SizedBox(height: 12),
              FutureBuilder<List<CourseModel>>(
                future: _coursesFuture,
                builder: (_, snap) {
                  if (snap.connectionState == ConnectionState.waiting)
                    return const Padding(padding: EdgeInsets.all(20), child: AppLoading());
                  final list = snap.data ?? [];
                  return Column(children: list.map((c) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: CourseTileGray(name: c.name, code: c.code, creditHours: c.creditHours),
                  )).toList());
                },
              ),
              const SizedBox(height: 28),
              const Text('My Schedule', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textDark, fontFamily: 'Poppins')),
              const SizedBox(height: 12),
              FutureBuilder<List<ScheduleItem>>(
                future: _scheduleFuture,
                builder: (_, snap) {
                  if (snap.connectionState == ConnectionState.waiting)
                    return const Padding(padding: EdgeInsets.all(20), child: AppLoading());
                  final list = snap.data ?? [];
                  return Column(children: list.map((s) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: ScheduleCard(courseName: s.courseName, days: s.days, timeRange: s.timeRange),
                  )).toList());
                },
              ),
              const SizedBox(height: 16),
            ]),
          ),
        ),
      ),
    );
  }
}
