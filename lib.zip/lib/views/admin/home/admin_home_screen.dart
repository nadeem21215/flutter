import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/providers/user_provider.dart';
import '../../../data/models/models.dart';
import '../../../data/services/api_service.dart';

class AdminHomeScreen extends StatefulWidget {
  const AdminHomeScreen({super.key});

  @override
  State<AdminHomeScreen> createState() => _AdminHomeScreenState();
}

class _AdminHomeScreenState extends State<AdminHomeScreen> {
  final _api = ApiService();
  late Future<AdminStats> _statsFuture;

  @override
  void initState() { super.initState(); _statsFuture = _api.getAdminStats(); }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<UserProvider>();
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

            // Header
            Row(children: [
              CircleAvatar(
                radius: 24,
                backgroundColor: AppColors.cardGray,
                child: const Icon(Icons.person_rounded, color: AppColors.textGray, size: 26),
              ),
              const SizedBox(width: 12),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Hi ${user.name ?? 'Admin'}!',
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700,
                        color: AppColors.textDark, fontFamily: 'Poppins')),
                const Text('Manage courses and students',
                    style: TextStyle(color: AppColors.textGray, fontSize: 12, fontFamily: 'Poppins')),
              ]),
            ]),

            const SizedBox(height: 20),

            // Stats banner
            FutureBuilder<AdminStats>(
              future: _statsFuture,
              builder: (_, snap) {
                final s = snap.data;
                return Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(22),
                  decoration: BoxDecoration(
                    color: AppColors.primary,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Stack(children: [
                    Positioned(right: -8, bottom: -8,
                      child: Container(
                        width: 80, height: 80,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.08),
                          shape: BoxShape.circle,
                        ),
                      ),
                    ),
                    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      _StatLine(label: 'Student',       value: '${s?.studentCount ?? '--'}'),
                      const SizedBox(height: 6),
                      _StatLine(label: 'Courses',       value: '${s?.courseCount  ?? '--'}'),
                      const SizedBox(height: 6),
                      _StatLine(label: 'Academic Year', value: s?.academicYear ?? '--'),
                    ]),
                  ]),
                );
              },
            ),

            const SizedBox(height: 40),

            // Watermark logo
            Center(
              child: Opacity(
                opacity: 0.12,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.school_rounded, size: 100, color: AppColors.primary),
                  const Text('Smart', style: TextStyle(
                      fontSize: 28, fontWeight: FontWeight.w800,
                      color: AppColors.primary, fontFamily: 'Poppins')),
                  const Text('Institute', style: TextStyle(
                      fontSize: 24, fontWeight: FontWeight.w300,
                      color: AppColors.primary, fontFamily: 'Poppins')),
                  const Text('App', style: TextStyle(
                      fontSize: 28, fontWeight: FontWeight.w800,
                      color: AppColors.primary, fontFamily: 'Poppins')),
                ]),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}

class _StatLine extends StatelessWidget {
  final String label;
  final String value;
  const _StatLine({required this.label, required this.value});

  @override
  Widget build(BuildContext context) => RichText(
    text: TextSpan(
      style: const TextStyle(fontSize: 17, fontFamily: 'Poppins'),
      children: [
        TextSpan(text: '$label : ',
            style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.white)),
        TextSpan(text: value,
            style: const TextStyle(fontWeight: FontWeight.w400, color: Colors.white70)),
      ],
    ),
  );
}
