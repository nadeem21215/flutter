import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/network/http_exception.dart';
import '../../../data/models/models.dart';
import '../../../data/services/api_service.dart';
import '../../widgets/shared_widgets.dart';

class AdminCoursesScreen extends StatefulWidget {
  const AdminCoursesScreen({super.key});

  @override
  State<AdminCoursesScreen> createState() => _AdminCoursesScreenState();
}

class _AdminCoursesScreenState extends State<AdminCoursesScreen> {
  final _api = ApiService();
  List<CourseModel> _all      = [];
  List<CourseModel> _filtered = [];
  bool   _loading = true;
  String? _error;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final list = await _api.getAllCourses();
      setState(() { _all = list; _filtered = list; _loading = false; });
    } on HttpException catch (e) {
      setState(() { _error = e.message; _loading = false; });
    }
  }

  void _search(String q) {
    setState(() {
      _filtered = q.isEmpty
          ? List.from(_all)
          : _all.where((c) =>
              c.name.toLowerCase().contains(q.toLowerCase()) ||
              c.code.toLowerCase().contains(q.toLowerCase())).toList();
    });
  }

  // ── Remove course ──────────────────────────────────────────────────────────
  Future<void> _removeCourse(CourseModel course) async {
    final ok = await showConfirmDialog(
      context: context,
      message: 'Are you sure you want to remove course',
    );
    if (ok != true) return;
    try {
      await _api.removeCourse(courseId: course.id);
      showSuccess(context, '${course.name} removed');
      _load();
    } on HttpException catch (e) {
      showError(context, e.message);
    }
  }

  // ── Add course dialog ──────────────────────────────────────────────────────
  void _showAddDialog() {
    final nameCtrl  = TextEditingController();
    final codeCtrl  = TextEditingController();
    final hoursCtrl = TextEditingController();
    final formKey   = GlobalKey<FormState>();
    bool  saving    = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => Padding(
          padding: EdgeInsets.only(
            left: 24, right: 24, top: 28,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
          ),
          child: Form(
            key: formKey,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              _AddLabel('Name Course'),
              const SizedBox(height: 8),
              _AddField(ctrl: nameCtrl, hint: ''),
              const SizedBox(height: 16),
              _AddLabel('Code Course'),
              const SizedBox(height: 8),
              _AddField(ctrl: codeCtrl, hint: '', ltr: true),
              const SizedBox(height: 16),
              _AddLabel('Credit Hours'),
              const SizedBox(height: 8),
              _AddField(ctrl: hoursCtrl, hint: '', numeric: true),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: saving ? null : () async {
                  if (!formKey.currentState!.validate()) return;
                  setS(() => saving = true);
                  try {
                    await _api.addCourse(
                      name:        nameCtrl.text.trim(),
                      code:        codeCtrl.text.trim(),
                      creditHours: int.tryParse(hoursCtrl.text.trim()) ?? 3,
                    );
                    if (!ctx.mounted) return;
                    Navigator.pop(ctx);
                    _load();
                    showSuccess(context, 'Course added successfully');
                  } on HttpException catch (e) {
                    setS(() => saving = false);
                    showError(context, e.message);
                  }
                },
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(140, 50),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
                ),
                child: saving
                    ? const SizedBox(width: 20, height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Text('Add'),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.background,
    appBar: AppBar(
      title: const Text('Courses'),
      actions: [IconButton(icon: const Icon(Icons.arrow_forward_rounded), onPressed: () {})],
      automaticallyImplyLeading: false,
    ),
    body: _loading
        ? const AppLoading()
        : _error != null
            ? AppError(message: _error!, onRetry: _load)
            : Column(children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
                  child: AppSearchBar(onChanged: _search),
                ),
                Expanded(
                  child: RefreshIndicator(
                    onRefresh: _load,
                    color: AppColors.primary,
                    child: ListView.separated(
                      padding: const EdgeInsets.fromLTRB(20, 4, 20, 90),
                      itemCount: _filtered.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (_, i) {
                        final c = _filtered[i];
                        return CourseTileBlue(
                          name:        c.name,
                          code:        c.code,
                          creditHours: c.creditHours,
                          trailing: _ThreeDotMenu(
                            onRemove: () => _removeCourse(c),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ]),
    floatingActionButton: FloatingActionButton(
      backgroundColor: AppColors.primary,
      onPressed: _showAddDialog,
      child: const Icon(Icons.add_rounded, color: Colors.white),
    ),
  );
}

// ─── 3-dot menu ───────────────────────────────────────────────────────────────
class _ThreeDotMenu extends StatelessWidget {
  final VoidCallback onRemove;
  const _ThreeDotMenu({required this.onRemove});

  @override
  Widget build(BuildContext context) => PopupMenuButton<String>(
    icon: const Icon(Icons.more_vert_rounded, color: AppColors.textGray),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    onSelected: (v) { if (v == 'remove') onRemove(); },
    itemBuilder: (_) => [
      const PopupMenuItem(
        value: 'remove',
        child: Text('Remove Course',
            style: TextStyle(color: AppColors.textRed, fontWeight: FontWeight.w600,
                fontFamily: 'Poppins')),
      ),
    ],
  );
}

// ─── Add form helpers ─────────────────────────────────────────────────────────
class _AddLabel extends StatelessWidget {
  final String text;
  const _AddLabel(this.text);
  @override
  Widget build(BuildContext context) => Text(text,
      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600,
          color: AppColors.textDark, fontFamily: 'Poppins'));
}

class _AddField extends StatelessWidget {
  final TextEditingController ctrl;
  final String hint;
  final bool ltr;
  final bool numeric;
  const _AddField({required this.ctrl, required this.hint,
      this.ltr = false, this.numeric = false});

  @override
  Widget build(BuildContext context) => TextFormField(
    controller: ctrl,
    textDirection: ltr ? TextDirection.ltr : null,
    keyboardType: numeric ? TextInputType.number : null,
    decoration: InputDecoration(hintText: hint),
    validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
  );
}
