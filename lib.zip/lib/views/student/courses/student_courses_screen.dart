import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/providers/user_provider.dart';
import '../../../core/network/http_exception.dart';
import '../../../data/models/models.dart';
import '../../../data/services/api_service.dart';
import '../../widgets/shared_widgets.dart';
import 'register_courses_screen.dart';

class StudentCoursesScreen extends StatefulWidget {
  const StudentCoursesScreen({super.key});

  @override
  State<StudentCoursesScreen> createState() => _StudentCoursesScreenState();
}

class _StudentCoursesScreenState extends State<StudentCoursesScreen> {
  final _api = ApiService();
  List<CourseModel> _courses = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final uid = context.read<UserProvider>().firebaseUid ?? '';
    setState(() { _loading = true; _error = null; });
    try {
      final res = await _api.getStudentRegisteredCourses(firebaseUid: uid);
      setState(() { _courses = res; _loading = false; });
    } on HttpException catch (e) {
      setState(() { _error = e.message; _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.background,
    appBar: AppBar(
      title: const Text('My Courses'),
      actions: [IconButton(icon: const Icon(Icons.arrow_forward_rounded), onPressed: () {})],
      automaticallyImplyLeading: false,
    ),
    body: _loading
        ? const AppLoading()
        : _error != null
            ? AppError(message: _error!, onRetry: _load)
            : RefreshIndicator(
                onRefresh: _load,
                color: AppColors.primary,
                child: _courses.isEmpty
                    ? ListView(children: const [
                        SizedBox(height: 120),
                        Center(child: Text('No enrolled courses yet.',
                            style: TextStyle(color: AppColors.textGray, fontFamily: 'Poppins'))),
                      ])
                    : ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: _courses.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (_, i) => CourseTileBlue(
                          name:        _courses[i].name,
                          code:        _courses[i].code,
                          creditHours: _courses[i].creditHours,
                        ),
                      ),
              ),
    floatingActionButton: FloatingActionButton(
      backgroundColor: AppColors.primary,
      onPressed: () async {
        await Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterCoursesScreen()));
        _load();
      },
      child: const Icon(Icons.add_rounded, color: Colors.white),
    ),
  );
}