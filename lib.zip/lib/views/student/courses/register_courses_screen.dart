import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/providers/user_provider.dart';
import '../../../core/network/http_exception.dart';
import '../../../data/models/models.dart';
import '../../../data/services/api_service.dart';
import '../../widgets/shared_widgets.dart';

class RegisterCoursesScreen extends StatefulWidget {
  const RegisterCoursesScreen({super.key});
  @override
  State<RegisterCoursesScreen> createState() => _RegisterCoursesScreenState();
}

class _RegisterCoursesScreenState extends State<RegisterCoursesScreen> {
  final _api = ApiService();
  List<CourseModel> _courses = [];
  List<CourseModel> _filtered = [];
  bool _loading = true;
  bool _submitting = false;
  String? _error;
  String _search = '';

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final uid = context.read<UserProvider>().firebaseUid ?? '';
    setState(() { _loading = true; _error = null; });
    try {
      final list = await _api.getCourses(firebaseUid: uid);
      setState(() { _courses = list; _applySearch(); _loading = false; });
    } on HttpException catch (e) {
      setState(() { _error = e.message; _loading = false; });
    }
  }

  void _applySearch() {
    final q = _search.toLowerCase();
    _filtered = q.isEmpty ? List.from(_courses)
        : _courses.where((c) => c.name.toLowerCase().contains(q) || c.code.toLowerCase().contains(q)).toList();
  }

  int get _selectedCredits => _courses.where((c) => c.isEnrolled).fold(0, (s, c) => s + c.creditHours);

  void _toggle(CourseModel course) {
    if (!course.isAvailable) return;
    final newEnrolled = !course.isEnrolled;
    final newCredits = _selectedCredits + (newEnrolled ? course.creditHours : -course.creditHours);
    if (newEnrolled && newCredits > AppConstants.maxCreditHours) return;
    setState(() {
      final idx = _courses.indexWhere((c) => c.id == course.id);
      if (idx >= 0) _courses[idx] = course.copyWith(isEnrolled: newEnrolled);
      final total = _selectedCredits;
      for (int i = 0; i < _courses.length; i++) {
        final c = _courses[i];
        if (!c.isEnrolled) _courses[i] = c.copyWith(isAvailable: total + c.creditHours <= AppConstants.maxCreditHours);
      }
      _applySearch();
    });
  }

  Future<void> _register() async {
    final selected = _courses.where((c) => c.isEnrolled).toList();
    if (selected.isEmpty) return;
    final confirmed = await showConfirmDialog(context: context,
        message: 'Are you sure you want to continue with this registration?');
    if (confirmed != true) return;
    final uid = context.read<UserProvider>().firebaseUid ?? '';
    setState(() => _submitting = true);
    try {
      await _api.enrollCourseByCodes(firebaseUid: uid, courseCodes: selected.map((c) => c.code).toList());
      if (!mounted) return;
      showSuccess(context, 'Courses registered successfully!');
      Navigator.pop(context);
    } on HttpException catch (e) {
      showError(context, e.message);
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.background,
    appBar: AppBar(
      title: const Text('Register Courses'),
      actions: [IconButton(icon: const Icon(Icons.arrow_forward_rounded), onPressed: () => Navigator.pop(context))],
      automaticallyImplyLeading: false,
    ),
    body: _loading ? const AppLoading()
        : _error != null ? AppError(message: _error!, onRetry: _load)
        : Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
              child: Column(children: [
                AppSearchBar(onChanged: (v) => setState(() { _search = v; _applySearch(); })),
                const SizedBox(height: 10),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('Allowed Credit Hours: ${AppConstants.maxCreditHours}',
                      style: const TextStyle(fontSize: 12, color: AppColors.textGray, fontFamily: 'Poppins')),
                  Text('Selected Credit Hours: $_selectedCredits',
                      style: const TextStyle(fontSize: 12, color: AppColors.textGray, fontFamily: 'Poppins')),
                ]),
              ]),
            ),
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 90),
                itemCount: _filtered.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (_, i) {
                  final c = _filtered[i];
                  return GestureDetector(
                    onTap: () => _toggle(c),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                      decoration: BoxDecoration(
                        color: c.isEnrolled ? AppColors.cardBlue : c.isAvailable ? AppColors.background : AppColors.cardGray,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: c.isEnrolled ? AppColors.cardBlue : c.isAvailable ? AppColors.divider : Colors.transparent),
                      ),
                      child: Row(children: [
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(c.name, style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15,
                              color: c.isAvailable || c.isEnrolled ? AppColors.textDark : AppColors.textGray,
                              fontFamily: 'Poppins')),
                          const SizedBox(height: 4),
                          Row(children: [
                            Text(c.code, style: TextStyle(color: c.isAvailable || c.isEnrolled ? AppColors.textBlue : AppColors.textGray,
                                fontSize: 13, fontWeight: FontWeight.w500, fontFamily: 'Poppins')),
                            const SizedBox(width: 16),
                            Text('${c.creditHours} Credit Hours', style: TextStyle(
                                color: c.isAvailable || c.isEnrolled ? AppColors.textBlue : AppColors.textGray,
                                fontSize: 13, fontFamily: 'Poppins')),
                          ]),
                        ])),
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          width: 26, height: 26,
                          decoration: BoxDecoration(
                            color: c.isEnrolled ? AppColors.primary : Colors.transparent,
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: c.isEnrolled ? AppColors.primary : c.isAvailable ? AppColors.highlight : AppColors.textGray, width: 1.5),
                          ),
                          child: c.isEnrolled ? const Icon(Icons.check_rounded, color: Colors.white, size: 18) : null,
                        ),
                      ]),
                    ),
                  );
                },
              ),
            ),
          ]),
    bottomSheet: Container(
      color: AppColors.background,
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 20),
      child: ElevatedButton(
        onPressed: _submitting ? null : _register,
        style: ElevatedButton.styleFrom(backgroundColor: _selectedCredits > 0 ? AppColors.primary : AppColors.textGray.withOpacity(0.4)),
        child: _submitting
            ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
            : const Text('Register'),
      ),
    ),
  );
}
