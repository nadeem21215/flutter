import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/user_images.dart';
import '../../../core/providers/user_provider.dart';
import '../../../data/models/models.dart';
import '../../../data/services/api_service.dart';
import '../../widgets/shared_widgets.dart';
import '../courses/register_courses_screen.dart';

class StudentHomeScreen extends StatefulWidget {
  const StudentHomeScreen({super.key});
  @override
  State<StudentHomeScreen> createState() => _StudentHomeScreenState();
}

class _StudentHomeScreenState extends State<StudentHomeScreen> {
  final _api = ApiService();
  late Future<List<ScheduleItem>> _scheduleFuture;

  @override
  void initState() { super.initState(); _loadSchedule(); }

  void _loadSchedule() {
    final uid = context.read<UserProvider>().firebaseUid ?? '';
    _scheduleFuture = _api.getSchedule(firebaseUid: uid);
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<UserProvider>();
    final imageBytes = UserImages.getImageBytes(user.firebaseUid);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () async => setState(_loadSchedule),
          color: AppColors.primary,
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                CircleAvatar(
                  radius: 26,
                  backgroundColor: AppColors.cardGray,
                  backgroundImage: imageBytes != null ? MemoryImage(imageBytes) : null,
                  child: imageBytes == null ? const Icon(Icons.person_rounded, color: AppColors.textGray, size: 28) : null,
                ),
                const SizedBox(width: 12),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Text('Hi ${user.name ?? 'Student'}!', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.textDark, fontFamily: 'Poppins')),
                    const SizedBox(width: 6),
                    const Text('👋', style: TextStyle(fontSize: 18)),
                  ]),
                  Text(user.level ?? 'Student', style: const TextStyle(color: AppColors.textGray, fontSize: 13, fontFamily: 'Poppins')),
                ]),
              ]),
              const SizedBox(height: 20),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(20)),
                child: Stack(children: [
                  Positioned(right: -10, bottom: -10,
                    child: Container(width: 80, height: 80, decoration: BoxDecoration(color: Colors.white.withOpacity(0.08), shape: BoxShape.circle))),
                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Welcome to the\nSmart Institute App!', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: Colors.white, height: 1.4, fontFamily: 'Poppins')),
                    const SizedBox(height: 8),
                    const Text('Register your courses easily\nand get smart recommendations.', style: TextStyle(fontSize: 13, color: Colors.white70, height: 1.5, fontFamily: 'Poppins')),
                    const SizedBox(height: 16),
                    GestureDetector(
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterCoursesScreen())),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 9),
                        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
                        child: const Text('Register Courses', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.primary, fontFamily: 'Poppins')),
                      ),
                    ),
                  ]),
                ]),
              ),
              const SizedBox(height: 24),
              Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                _StatItem(label: 'Warnings',     value: '${user.warnings    ?? 0}'),
                _StatItem(label: 'Credit Hours', value: '${user.creditHours ?? 0}'),
                _StatItem(label: 'GPA',          value: (user.gpa ?? 0.0).toStringAsFixed(1)),
              ]),
              const SizedBox(height: 28),
              const Text('My Schedule', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textDark, fontFamily: 'Poppins')),
              const SizedBox(height: 12),
              FutureBuilder<List<ScheduleItem>>(
                future: _scheduleFuture,
                builder: (ctx, snap) {
                  if (snap.connectionState == ConnectionState.waiting)
                    return const Padding(padding: EdgeInsets.all(24), child: AppLoading());
                  final items = snap.data ?? [];
                  if (items.isEmpty)
                    return const Padding(padding: EdgeInsets.all(20), child: Text('No schedule yet.', style: TextStyle(color: AppColors.textGray)));
                  return Column(children: items.map((s) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: ScheduleCard(courseName: s.courseName, days: s.days, timeRange: s.timeRange),
                  )).toList());
                },
              ),
              const SizedBox(height: 16),
            ]),
          ),
        ),
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final String label;
  final String value;
  const _StatItem({required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Column(children: [
    Text(label, style: const TextStyle(fontSize: 13, color: AppColors.textGray, fontFamily: 'Poppins')),
    const SizedBox(height: 4),
    Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.textDark, fontFamily: 'Poppins')),
  ]);
}
